# nhl_linemate_scraper/__init__.py

from .scraper import scrape_game
