# nhl-linemate-scraper
 A Python scraper to gather NHL shift data and transform it to a more useful schema
